package rushhour_prototyp;

import com.trolltech.qt.gui.*;
import com.trolltech.qt.*;
import java.util.*;
import com.trolltech.qt.core.*;

public class Main {

    public static class RushHour extends QMainWindow {
        private Iterator<pictureID> itLOC;
        private LinkedList<pictureID> listOfCars = new LinkedList<pictureID>();
        private int unique_carID = 0;

        private paintWall paintMap;
        private QAction newGame;
        private QAction saveGame;
        private QAction loadGame;
        private QAction backGame;
        private QAction exitGame;
        private QAction ruleHelp;
        private QPushButton tippButton;
        private QPushButton answerButton;

        private class paintWall extends QFrame {
            private boolean active = false;
            private pictureID dragingCar = null;
            private QPoint backupPoint = new QPoint( 0, 0);
            private QPoint diffPoint = new QPoint( 0, 0);
            private QPoint veloVect = new QPoint( 0, 0);
            private QPoint endPos = new QPoint( 0, 0);
            private QRect intersetRect = new QRect();


            paintWall() {
                this.setFrameStyle( 0);
                this.setAcceptDrops(true);
            }

            private QBitArray doCollide( QMouseEvent event){
                QBitArray collision = new QBitArray( 8);
                /* 0 - window top
                 * 1 - window right
                 * 2 - window bottom
                 * 3 - window left
                 * 4 - car top
                 * 5 - car right
                 * 6 - car bottom
                 * 7 - car left
                 */
                if( dragingCar.x() < 0 )
                    collision.setBit( 3, true);
                if( dragingCar.x() > this.width() - dragingCar.width())
                    collision.setBit( 1, true);
                if( dragingCar.y() < 0)
                    collision.setBit( 0, true);
                if(  dragingCar.y() > this.height() - dragingCar.height())
                    collision.setBit( 2, true);
                /*
                 AußenWände ??

                 wenn Kollision -> Auto bis an Rand schieben -> keine Zwischenräume (
                  so, wie wenn man es langsam machen würde)

                 */
                pictureID testpID;
                itLOC = listOfCars.iterator();
                while( itLOC.hasNext()){
                    testpID = itLOC.next();
                    if( testpID.geometry().intersects(  dragingCar.geometry()) && testpID != dragingCar){
                        intersetRect = testpID.geometry().intersected(  dragingCar.geometry());
                        // intersection ? ? ?

                        
                        break;
                    }
                }
                return collision;
            }

            private QPoint getVelocity( QMouseEvent event){
                veloVect.setX( event.x() - dragingCar.pos().x());
                veloVect.setY(event.y() - dragingCar.pos().y());
                return veloVect;
            }

            protected void mousePressEvent(QMouseEvent event) {
                pictureID child = ( pictureID) childAt(event.pos());
                if (child == null) {
                    return;
                }
                if( !active){
                    active = true;
                    dragingCar = child;
                    getVelocity( event);
                    diffPoint.setX(veloVect.x());
                    diffPoint.setY(veloVect.y());
                }
            }

            protected void mouseMoveEvent( QMouseEvent event){
                if( active){
                    backupPoint = dragingCar.pos();
                    getVelocity(event);

                    endPos.setX(0);
                    endPos.setY( 0);
                    
                    dragingCar.move( endPos.add( dragingCar.pos()).add( veloVect).subtract( diffPoint));
                    
                    /*switch( doCollide(event).){
                        default:
                            break;
                    }

                    if( doCollide( event))
                        dragingCar.move( backupPoint);*/
                }
            }

            protected void mouseReleaseEvent(QMouseEvent event) {
                if( active){
                    diffPoint.setX( 0);
                    diffPoint.setY( 0);
                    active = false;
                    dragingCar = null;
                }
            }
        }

        
        public class pictureID extends QLabel{
            public int ID=++unique_carID;
            public pictureID( paintWall pW) {
                super( pW);
            }
        }

        private class aCar extends QLabel{
            private pictureID picture;

            aCar(paintWall aWall, String file) {
                picture = new pictureID( aWall);
                picture.setPixmap(new QPixmap(file));
                listOfCars.add( picture);
            }

            public pictureID getPicture() {
                return picture;
            }
        }

        RushHour() {
            initWindow();
            initMenu();
            initLayout();
            initCar();
            connectAction();
        }

        void initWindow() {
            QWidget mainWidget = new QWidget(this);
            paintMap = new paintWall();
            this.setWindowTitle("Rush Hour - Prototyp");
            this.setGeometry( 32, 32, 640+32, 480+32);
            this.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed);

            this.setCentralWidget(mainWidget);

        }

        void initMenu() {
            QMenu gameMenu = new QMenu(tr("&Spiel"), this.menuBar());
            QMenu helpMenu = new QMenu(tr("&Hilfe"), this.menuBar());
            newGame = new QAction(tr("&neu"), gameMenu);
            saveGame = new QAction(tr("&speichern"), gameMenu);
            loadGame = new QAction(tr("&laden"), gameMenu);
            backGame = new QAction(tr("&zurücksetzten"), gameMenu);
            exitGame = new QAction(tr("&beenden"), gameMenu);
            ruleHelp = new QAction(tr("&Regeln"), helpMenu);

            tippButton = new QPushButton(tr("&Tipp"));
            answerButton = new QPushButton(tr("&Lösung"));

            gameMenu.addAction(newGame);
            gameMenu.addAction(saveGame);
            gameMenu.addAction(loadGame);
            gameMenu.addAction(backGame);
            gameMenu.addSeparator();
            gameMenu.addAction(exitGame);

            helpMenu.addAction(ruleHelp);

            this.menuBar().addMenu(gameMenu);
            this.menuBar().addMenu(helpMenu);
            this.menuBar().show();

        }

        void initLayout() {
            QVBoxLayout verticalLayout = new QVBoxLayout(this.centralWidget());
            QHBoxLayout horizontalLayout = new QHBoxLayout();
            QSpacerItem aSpace = new QSpacerItem(0, 0, QSizePolicy.Policy.MinimumExpanding, QSizePolicy.Policy.Fixed);

            verticalLayout.addWidget(paintMap);
            verticalLayout.addLayout(horizontalLayout);
            horizontalLayout.addSpacerItem(aSpace);
            horizontalLayout.addWidget(tippButton);
            horizontalLayout.addWidget(answerButton);
            horizontalLayout.addSpacerItem(aSpace);
        }

        void initCar() {
            aCar littleCar = new aCar(paintMap, "test_auto.jpg");
            littleCar.picture.move(32, 32);
            aCar bigCar = new aCar(paintMap, "test_auto.jpg");
            littleCar.picture.move( 320, 240);
        }

        void connectAction(){
            ruleHelp.setShortcut("F1");
            exitGame.triggered.connect(QApplication.instance(), "quit()");

            /*
             * verbinden einzellner getriggerter Aktionen mit eigenen Funktionen
             */
        }
    }

    public static void main(String[] args) {
        QApplication.initialize(args);
        RushHour app = new RushHour();
        app.show();
        QApplication.exec();
    }
}
