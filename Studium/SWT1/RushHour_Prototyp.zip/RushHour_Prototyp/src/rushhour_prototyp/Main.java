package rushhour_prototyp;

import com.trolltech.qt.gui.*;
import java.util.*;
import com.trolltech.qt.core.*;

public class Main {

    public static class RushHour extends QMainWindow {
        private Iterator<pictureID> itLOC;
        private pictureID testpID;
        private LinkedList<pictureID> listOfCars = new LinkedList<pictureID>();
        private int unique_carID = 0;

        private paintWall paintMap;
        private QAction newGame;
        private QAction saveGame;
        private QAction loadGame;
        private QAction backGame;
        private QAction exitGame;
        private QAction ruleHelp;
        private QPushButton tippButton;
        private QPushButton answerButton;

        private class paintWall extends QFrame {
            private boolean active = false;
            private pictureID dragingCar = null;
            QPoint backupPoint = new QPoint( 0, 0);
            QPoint diffPoint = new QPoint( 0, 0);
            QPoint veloVect = new QPoint( 0, 0);
            QPoint endPos = new QPoint( 0, 0);

            paintWall() {
                this.setFrameStyle( 0);
                this.setAcceptDrops(true);
            }

            private boolean doCollide(){
                if( dragingCar.x() < 0 || dragingCar.x() > this.width() - dragingCar.width())
                    return true;
                if( dragingCar.y() < 0 || dragingCar.y() > this.height() - dragingCar.height())
                    return true;

                
                itLOC = listOfCars.iterator();
                while( itLOC.hasNext()){
                    testpID = itLOC.next();
                    if( testpID.geometry().intersects( dragingCar.geometry()) && testpID != dragingCar){
                            return true;
                    }
                }
                return false;
            }

            private QPoint getVelocity( QMouseEvent event){
                veloVect.setX( event.x() - dragingCar.pos().x());
                veloVect.setY(event.y() - dragingCar.pos().y());
                return veloVect;
            }

            protected void mousePressEvent(QMouseEvent event) {
                pictureID child = ( pictureID) childAt(event.pos());
                if (child == null) {
                    return;
                }
                if( !active){
                    active = true;
                    dragingCar = child;
                    getVelocity( event);
                    diffPoint.setX(veloVect.x());
                    diffPoint.setY(veloVect.y());
                }
            }

            protected void mouseMoveEvent( QMouseEvent event){
                if( active){
                    backupPoint = dragingCar.pos();
                    getVelocity(event);

                    endPos.setX(0);
                    endPos.setY( 0);
                    
                    dragingCar.move( endPos.add( dragingCar.pos()).add( veloVect).subtract( diffPoint));
                    if( doCollide())
                        dragingCar.move( backupPoint);
                }
            }

            protected void mouseReleaseEvent(QMouseEvent event) {
                if( active){
                    diffPoint.setX( 0);
                    diffPoint.setY( 0);
                    active = false;
                    dragingCar = null;
                }
            }
        }

        public class pictureID extends QLabel{
            public int ID=++unique_carID;
            public pictureID( paintWall pW) {
                super( pW);
            }
        }

        private class aCar extends QLabel{
            private pictureID picture;

            aCar(paintWall aWall, String file) {
                QPixmap tmpPixmap = new QPixmap(file);
                picture = new pictureID( aWall);
                picture.setPixmap( tmpPixmap);
                picture.show();
                listOfCars.add( picture);
            }

            public pictureID getPicture() {
                return picture;
            }
        }

        RushHour() {
            initWindow();
            initMenu();
            initLayout();
            connectAction();
            initCar();
        }

        void initWindow() {
            QWidget mainWidget = new QWidget(this);

            paintMap = new paintWall();

            this.setWindowTitle("Rush Hour - Prototyp");
            this.setMinimumWidth( 640);
            this.setMaximumWidth( 640);
            this.setMinimumHeight( 480);
            this.setMaximumHeight( 480);

            this.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed);

            this.setCentralWidget(mainWidget);
        }

        void initMenu() {
            QMenu gameMenu = new QMenu(tr("&Spiel"), this.menuBar());
            QMenu helpMenu = new QMenu(tr("&Hilfe"), this.menuBar());
            newGame = new QAction(tr("&neu"), gameMenu);
            saveGame = new QAction(tr("&speichern"), gameMenu);
            loadGame = new QAction(tr("&laden"), gameMenu);
            backGame = new QAction(tr("&zurücksetzten"), gameMenu);
            exitGame = new QAction(tr("&beenden"), gameMenu);
            ruleHelp = new QAction(tr("&Regeln"), helpMenu);

            tippButton = new QPushButton(tr("&Tipp"));
            answerButton = new QPushButton(tr("&Lösung"));

            gameMenu.addAction(newGame);
            gameMenu.addAction(saveGame);
            gameMenu.addAction(loadGame);
            gameMenu.addAction(backGame);
            gameMenu.addSeparator();
            gameMenu.addAction(exitGame);

            helpMenu.addAction(ruleHelp);

            this.menuBar().addMenu(gameMenu);
            this.menuBar().addMenu(helpMenu);
            this.menuBar().show();

        }

        void initLayout() {
            QVBoxLayout verticalLayout = new QVBoxLayout(this.centralWidget());
            QHBoxLayout horizontalLayout = new QHBoxLayout();
            QSpacerItem aSpace = new QSpacerItem(0, 0, QSizePolicy.Policy.MinimumExpanding, QSizePolicy.Policy.Fixed);

            verticalLayout.addWidget(paintMap);
            verticalLayout.addLayout(horizontalLayout);
            horizontalLayout.addSpacerItem(aSpace);
            horizontalLayout.addWidget(tippButton);
            horizontalLayout.addWidget(answerButton);
            horizontalLayout.addSpacerItem(aSpace);
        }

        void initCar() {

            aCar blueCarW = new aCar(paintMap, "cars/blue_car_w.png");
            aCar blueCarH = new aCar(paintMap, "cars/blue_car_h.png");
            aCar redCarW = new aCar( paintMap, "cars/red_car_w.png");
            aCar redCarH = new aCar( paintMap, "cars/red_car_h.png");
            aCar greenCar1 = new aCar( paintMap, "cars/green_car.png");
            aCar greenCar2 = new aCar( paintMap, "cars/green_car.png");

            aCar blueCarW2 = new aCar(paintMap, "cars/blue_car_w.png");
            aCar blueCarH2 = new aCar(paintMap, "cars/blue_car_h.png");
            aCar redCarW2 = new aCar( paintMap, "cars/red_car_w.png");
            aCar redCarH2 = new aCar( paintMap, "cars/red_car_h.png");
            aCar greenCar12 = new aCar( paintMap, "cars/green_car.png");
            aCar greenCar22 = new aCar( paintMap, "cars/green_car.png");

            aCar yourCar = new aCar( paintMap, "cars/your_car.png");


            blueCarW.picture.move(32, 16);
            blueCarH.picture.move( 320, 240);
            redCarH.picture.move( 128, 148);
            redCarW.picture.move( 256, 10);
            greenCar1.picture.move( 32, 240);
            greenCar2.picture.move( 400, 300);
            
            blueCarW2.picture.move( 256, 152);
            blueCarH2.picture.move( 32, 96);
            redCarH2.picture.move( 520, 148);
            redCarW2.picture.move( 256, 85);
            greenCar12.picture.move( 32, 320);
            greenCar22.picture.move( 520, 16);

            yourCar.picture.move( 150, 86);
        }

        private void makeNewGame(){
            itLOC = listOfCars.iterator();
            while( itLOC.hasNext()){
                testpID = itLOC.next();
                testpID.clear();
            }
            listOfCars.clear();
            this.initCar();
        }

        private void saveGame(){
            QWidget undone = new QWidget();
            QVBoxLayout undoneLayout = new QVBoxLayout( undone);
            QLabel undoneText = new QLabel( tr( "nicht implementiert"), undone);
            QPushButton undoneOK = new QPushButton( tr("&OK"), undone);

            undoneLayout.addWidget( undoneText);
            undoneLayout.addWidget( undoneOK);
            undone.setWindowTitle( tr( "speichern"));
            undone.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed);
            undoneOK.clicked.connect( undone, "close()");

            undone.show();
        }

        private void loadGame(){
            QWidget undone = new QWidget();
            QVBoxLayout undoneLayout = new QVBoxLayout( undone);
            QLabel undoneText = new QLabel( tr( "nicht implementiert"), undone);
            QPushButton undoneOK = new QPushButton( tr("&OK"), undone);

            undoneLayout.addWidget( undoneText);
            undoneLayout.addWidget( undoneOK);
            undone.setWindowTitle( tr( "laden"));
            undone.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed);
            undoneOK.clicked.connect( undone, "close()");

            undone.show();
        }

        private void backInGame(){
            QWidget undone = new QWidget();
            QVBoxLayout undoneLayout = new QVBoxLayout( undone);
            QLabel undoneText = new QLabel( tr( "nicht implementiert"), undone);
            QPushButton undoneOK = new QPushButton( tr("&OK"), undone);

            undoneLayout.addWidget( undoneText);
            undoneLayout.addWidget( undoneOK);
            undone.setWindowTitle( tr( "zurücksetzen"));
            undone.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed);
            undoneOK.clicked.connect( undone, "close()");

            undone.show();
        }

        private void tippForGame(){
            QWidget undone = new QWidget();
            QVBoxLayout undoneLayout = new QVBoxLayout( undone);
            QLabel undoneText = new QLabel( tr( "nicht implementiert"), undone);
            QPushButton undoneOK = new QPushButton( tr("&OK"), undone);

            undoneLayout.addWidget( undoneText);
            undoneLayout.addWidget( undoneOK);
            undone.setWindowTitle( tr( "Tipp"));
            undone.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed);
            undoneOK.clicked.connect( undone, "close()");

            undone.show();
        }
        
        private void answerForGame(){
            QWidget undone = new QWidget();
            QVBoxLayout undoneLayout = new QVBoxLayout( undone);
            QLabel undoneText = new QLabel( tr( "nicht implementiert"), undone);
            QPushButton undoneOK = new QPushButton( tr("&OK"), undone);

            undoneLayout.addWidget( undoneText);
            undoneLayout.addWidget( undoneOK);
            undone.setWindowTitle( tr( "Lösung"));
            undone.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed);
            undoneOK.clicked.connect( undone, "close()");

            undone.show();
        }

        private void rulesInGame(){
            QWidget undone = new QWidget();
            QVBoxLayout undoneLayout = new QVBoxLayout( undone);
            QLabel undoneText = new QLabel( tr( "nicht implementiert"), undone);
            QPushButton undoneOK = new QPushButton( tr("&OK"), undone);

            undoneLayout.addWidget( undoneText);
            undoneLayout.addWidget( undoneOK);
            undone.setWindowTitle( tr( "Regeln"));
            undone.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed);
            undoneOK.clicked.connect( undone, "close()");

            undone.show();
        }

        private void connectAction(){
            ruleHelp.setShortcut("F1");
            exitGame.triggered.connect(QApplication.instance(), "quit()");
            newGame.triggered.connect( this, "makeNewGame()" );
            saveGame.triggered.connect( this, "saveGame()");
            loadGame.triggered.connect( this, "loadGame()");
            backGame.triggered.connect( this, "backInGame()");
            ruleHelp.triggered.connect( this, "rulesInGame()");
            tippButton.clicked.connect( this, "tippForGame()");
            answerButton.clicked.connect( this, "answerForGame()");
        }
    }

    public static void main(String[] args) {
        QApplication.initialize(args);
        RushHour app = new RushHour();
        app.show();
        QApplication.exec();
    }
}
